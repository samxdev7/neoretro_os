#include <stdio.h>
#include <conio.h>
#include <graphics.h>
#include <stdlib.h>
#include <dos.h>
/*
	===== PRUEBA DE APLICACION DE RASTERIZACION =====
	Para poder tener mas nociones sobre el uso de la libreria
	raster.h se hizo este programa como ejemplo para poder aprender
	mas sobre como funciona cada funcion implementada, sirviendo de
	ayuda tambien para comprender las bases de rasterizacion y sobre
	como usar SVGA256.

	Si hay partes que no logra entender bien o quiere saber como funciona
	a profundidad una funcion o una sentencia por favor consulte desde
	diferentes fuentes o consulte de forma rapida con herramientas IA.

	- Samuel Rueda
*/

/*
    =======================================
    Importacion de Librerias Personalizadas
    =========================================
*/

#include "gphadmin.h"   /* Libreria que administra el modo grafico del sistema operativo */
#include "raster.h"   /* Libreria que contiene funciones para manejar la rasterizacion de imagenes */

typedef int bool;
#define true 1
#define false 0

typedef enum {
	NOTEPAD = 1,
	SHELL = 2,
	CALCULATOR = 3,
	PAINT = 4,
	CONFIG = 5,
	SHUT_DOWN = 6,
	RESTART = 7,
	LOCK = 8,
	CREDITS = 9
}iconos_t;

typedef enum {
	PX_20 = 20,
	PX_40 = 40
}px_size_t;

/* Declaracion de puntero a fichero (IMPORTANTE) */
FILE *file;

/* prototipado */
bool iniciar_modo_grafico(void);

bool notepad_icon_40px(int *, int *);
bool config_icon_40px(int *, int *);
bool calculator_icon_40px(int *, int *);
bool paint_icon_40px(int *, int *);
bool shell_icon_40px(int *, int *);

bool notepad_icon_20px(int *, int *);
bool config_icon_20px(int *, int *);
bool calculator_icon_20px(int *, int *);
bool paint_icon_20px(int *, int *);
bool shell_icon_20px(int *, int *);

bool credits_icon(int *, int *);
bool restart_icon(int *, int *);
bool shutdown_icon(int *, int *);
bool lock_icon(int *, int *);


/*
    =======================================
    Programa Principal
    =========================================
*/

int main() {
	
	bool valido = true;
	int opcion;
	int pos_x1 = 5, pos_y1 = 5;
	int pos_x2 = 100, pos_y2 = 5;

	do {
		clrscr();
		printf("\n");
		printf("===== Iconos =====\n");
		printf("(1) Icono notepad\n");
		printf("(2) Icono CLI\n");
		printf("(3) Icono calculator\n");
		printf("(4) Icono paint\n");
		printf("(5) Icono config\n");
		printf("(6) Icono apagar\n");
		printf("(7) Icono reiniciar\n");
		printf("(8) Icono suspender\n");
		printf("(9) Icono creditos\n");
		printf("(10) SALIR\n");
		printf("Elija una opcion para continuar: ");
		scanf("%d", &opcion);

		switch(opcion)
		{
			case NOTEPAD:
			{
				iniciar_modo_grafico();
				notepad_icon_40px(&pos_x1, &pos_y1);
				notepad_icon_20px(&pos_x2, &pos_y2);
				getch();
				getch_closegraph();
				break;
			}
			case SHELL:
			{
				iniciar_modo_grafico();
				shell_icon_40px(&pos_x1, &pos_y1);
				shell_icon_20px(&pos_x2, &pos_y2);
				getch();
				getch_closegraph();
				break;
			}
			case CALCULATOR:
			{
				iniciar_modo_grafico();
				calculator_icon_40px(&pos_x1, &pos_y1);
				calculator_icon_20px(&pos_x2, &pos_y2);
				getch();
				getch_closegraph();
				break;
			}
			case PAINT:
			{
				iniciar_modo_grafico();
				paint_icon_40px(&pos_x1, &pos_y1);
				paint_icon_20px(&pos_x2, &pos_y2);
				getch();
				getch_closegraph();
				break;
			}
			case CONFIG:
			{
				iniciar_modo_grafico();
				config_icon_40px(&pos_x1, &pos_y1);
				config_icon_20px(&pos_x2, &pos_y2);
				getch();
				getch_closegraph();
				break;
			}
			case SHUT_DOWN:
			{
				iniciar_modo_grafico();
				setfillstyle(SOLID_FILL, BLACK);
    			bar(0, 0, WIDTH, HEIGHT);
				shutdown_icon(&pos_x1, &pos_y1);
				getch();
				getch_closegraph();
				break;
			}
			case RESTART:
			{
				iniciar_modo_grafico();
				setfillstyle(SOLID_FILL, BLACK);
    			bar(0, 0, WIDTH, HEIGHT);
				restart_icon(&pos_x1, &pos_y1);
				getch();
				getch_closegraph();
				break;
			}
			case LOCK:
			{
				iniciar_modo_grafico();
				lock_icon(&pos_x1, &pos_y1);
				getch();
				getch_closegraph();
				break;
			}
			case CREDITS:
			{
				iniciar_modo_grafico();
				credits_icon(&pos_x1, &pos_y1);
				getch();
				getch_closegraph();
				break;
			}
			case 10:
			{
				valido = false;
				break;
			}
		}
	}while(valido);
    return EXIT_SUCCESS;
}

bool iniciar_modo_grafico(void)
{
	/* Iniciar modo grafico hacia BIN */
    if (iniciar_modo_svga_256("C:\\TC20\\BIN")) return false;

    /* Poner fondo blanco */
	setfillstyle(SOLID_FILL, WHITE);
    bar(0, 0, WIDTH, HEIGHT);
	return true;
}

bool notepad_icon_40px(int *pos_x, int *pos_y)
{
	file = fopen("NOTEVV.bin", "rb");

	if (validar_archivo(file)) return false;

	dibujar_raster_png_coords(file, *pos_x, *pos_y, PX_40, PX_40);

	/* Cerrar Archivo para ahorrar buffer */
	fclose(file);
	return true;
}

bool config_icon_40px(int *pos_x, int *pos_y)
{
	file = fopen("CONFVV.bin", "rb");

	if (validar_archivo(file)) return false;

	dibujar_raster_png_coords(file, *pos_x, *pos_y, PX_40, PX_40);

	/* Cerrar Archivo para ahorrar buffer */
	fclose(file);
	return true;
}

bool calculator_icon_40px(int *pos_x, int *pos_y)
{
	file = fopen("CALCVV.bin", "rb");

	if (validar_archivo(file)) return false;

	dibujar_raster_png_coords(file, *pos_x, *pos_y, PX_40, PX_40);

	/* Cerrar Archivo para ahorrar buffer */
	fclose(file);
	return true;
}

bool paint_icon_40px(int *pos_x, int *pos_y)
{
	file = fopen("PAINTVV.bin", "rb");

	if (validar_archivo(file)) return false;

	dibujar_raster_png_coords(file, *pos_x, *pos_y, PX_40, PX_40);
	/* Cerrar Archivo para ahorrar buffer */
	fclose(file);
	return true;
}

bool shell_icon_40px(int *pos_x, int *pos_y)
{
	file = fopen("SHELLVV.bin", "rb");

	if (validar_archivo(file)) return false;

	dibujar_raster_png_coords(file, *pos_x, *pos_y, PX_40, PX_40); 
	/* Cerrar Archivo para ahorrar buffer */
	fclose(file);
	return true;
}





bool notepad_icon_20px(int *pos_x, int *pos_y)
{
	file = fopen("NOTEVV2.bin", "rb");

	if (validar_archivo(file)) return false;

	dibujar_raster_png_coords(file, *pos_x, *pos_y, PX_20, PX_20);

	/* Cerrar Archivo para ahorrar buffer */
	fclose(file);
	return true;
}

bool config_icon_20px(int *pos_x, int *pos_y)
{
	file = fopen("CONFVV2.bin", "rb");

	if (validar_archivo(file)) return false;

	dibujar_raster_png_coords(file, *pos_x, *pos_y, PX_20, PX_20);

	/* Cerrar Archivo para ahorrar buffer */
	fclose(file);
	return true;
}

bool calculator_icon_20px(int *pos_x, int *pos_y)
{
	file = fopen("CALCVV2.bin", "rb");

	if (validar_archivo(file)) return false;

	dibujar_raster_png_coords(file, *pos_x, *pos_y, PX_20, PX_20);

	/* Cerrar Archivo para ahorrar buffer */
	fclose(file);
	return true;
}

bool paint_icon_20px(int *pos_x, int *pos_y)
{
	file = fopen("PAINTVV2.bin", "rb");

	if (validar_archivo(file)) return false;

	dibujar_raster_png_coords(file, *pos_x, *pos_y, PX_20, PX_20);
	/* Cerrar Archivo para ahorrar buffer */
	fclose(file);
	return true;
}

bool shell_icon_20px(int *pos_x, int *pos_y)
{
	file = fopen("SHELLVV2.bin", "rb");

	if (validar_archivo(file)) return false;

	dibujar_raster_png_coords(file, *pos_x, *pos_y, PX_20, PX_20); 
	/* Cerrar Archivo para ahorrar buffer */
	fclose(file);
	return true;
}





bool credits_icon(int *pos_x, int *pos_y)
{
	file = fopen("CREDVV.bin", "rb");

	if (validar_archivo(file)) return false;

	dibujar_raster_png_coords(file, *pos_x, *pos_y, PX_20, PX_20);
	/* Cerrar Archivo para ahorrar buffer */
	fclose(file);
	return true;
}
bool restart_icon(int *pos_x, int *pos_y)
{
	file = fopen("RESVV.bin", "rb");

	if (validar_archivo(file)) return false;

	dibujar_raster_png_coords(file, *pos_x, *pos_y, PX_20, PX_20);
	/* Cerrar Archivo para ahorrar buffer */
	fclose(file);
	return true;
}
bool shutdown_icon(int *pos_x, int *pos_y)
{
	file = fopen("SHUTVV.bin", "rb");

	if (validar_archivo(file)) return false;

	dibujar_raster_png_coords(file, *pos_x, *pos_y, PX_20, PX_20);
	/* Cerrar Archivo para ahorrar buffer */
	fclose(file);
	return true;
}
bool lock_icon(int *pos_x, int *pos_y)
{
	file = fopen("SUSVV.bin", "rb");

	if (validar_archivo(file)) return false;

	dibujar_raster_png_coords(file, *pos_x, *pos_y, PX_20, PX_20);
	/* Cerrar Archivo para ahorrar buffer */
	fclose(file);
	return true;
}
